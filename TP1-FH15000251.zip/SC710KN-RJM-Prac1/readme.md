# Mi Proyecto Node.js
Este proyecto en Node.js solicita un número al usuario, calcula la secuencia de Fibonacci hasta ese número y muestra cómo los cocientes de Fibonacci se aproximan al número áureo (phi), todo desde la consola. Ideal para practicar entrada y salida básica en Node.js.

## 🚀 Cómo ejecutar el aplicativo? en la terminal correr el comando
npm start

## repositorio de Git
https://github.com/ruzjim/PAW/tree/main/SC710KN-RJM-Prac1


## Paginas Web consultadas
No se consultaron paginas externas

## Prompts (consultas y respuestas) de los chatbots de IA
Este es el link al chat
https://chatgpt.com/share/6835349d-81a4-8003-b2da-5632b30c637a
También se uso copilot para obtener sugerencias de Código y auto-completado Inteligente