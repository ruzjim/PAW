# Estudiante
Rusdwin Jimenez Morales

# Carné
FH15000251

# Enlace Github
https://github.com/ruzjim/PAW/tree/main/20250713

# Comandos de dotnet utilizados (CLI).
dotnet new sln -n P4
dotnet new console -o Tarea4
dotnet sln add Tarea4
dotnet build
dotnet run
<!-- verifico paquetes globales -->
dotnet tool list --global

dotnet add package Microsoft.EntityFrameworkCore.Design
dotnet add package Microsoft.EntityFrameworkCore.Sqlite

<!-- crea la migracion -->
dotnet ef migrations add InitialCreate 
<!-- crea la bd -->
dotnet ef database update
<!-- actualiza la bd -->
otnet ef migrations add nombrerepresentativo
<!-- actualiza la bd -->
dotnet ef database update

# Paginas Web
no se utilizaron paginas de referencia

# Prompts
en el siguiente link están los prompts del IA
https://chatgpt.com/share/68749140-e8f8-8003-b55b-982b3c6aad53

